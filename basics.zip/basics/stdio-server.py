from fastmcp import FastMCP, Client
import asyncio

# Define server
mcp = FastMCP("demo")

@mcp.tool
def add_numbers(a: int, b: int) -> int:
    return a + b

async def test_client():
    async with Client(mcp) as client:
        tools = await client.list_tools()
        print("Tools exposed:", [t.name for t in tools])
        res = await client.call_tool("add_numbers", {"a": 4, "b": 8})
        print("Result of add_numbers(4, 8):", res)

if __name__ == "__main__":
    # Run client test first
    asyncio.run(test_client())

    # Then optionally start server for real clients
    print("Starting server for external clients (press Ctrl+C to quit)...")
    mcp.run(transport="stdio")
