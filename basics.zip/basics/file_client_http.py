import asyncio
from fastmcp.client import Client

async def main():
    url = "http://127.0.0.1:8000/mcp"
    async with Client(url) as client:
        tools = await client.list_tools()
        print("Tools available on server:", [t.name for t in tools])

        resp = await client.call_tool("read_file", {"path": "example.txt"})
        print("Raw response from read_file:", resp)

        # FastMCP returns a CallToolResult object
        data = resp.structured_content

        if data and data.get("ok"):
            print("\n--- File content start ---\n")
            print(data["text"])
            print("\n--- File content end ---\n")
        else:
            print("Error reading file:", data.get("error") if data else "Unknown error")

if __name__ == "__main__":
    asyncio.run(main())

'''What this does

Connects to your HTTP MCP server URL.

Optionally lists tools (shows that read_file is present).

Calls read_file with {"path": "example.txt"}.

Prints the raw response and nicely displays file content.'''