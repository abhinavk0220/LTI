from fastmcp import FastMCP

mcp = FastMCP("http-demo")

@mcp.tool
def add_numbers(a: int, b: int) -> int:
    return a + b

if __name__ == "__main__":
    print("Starting HTTP MCP server at http://127.0.0.1:8000/mcp")
    mcp.run(transport="http", host="127.0.0.1", port=8000, path="/mcp")
