# file_server_http.py
import os
from pathlib import Path
from fastmcp import FastMCP

# Configuration: safe root directory for file access
ROOT = Path.cwd() / "mcp_data"
ROOT.mkdir(exist_ok=True)

mcp = FastMCP("file-server")

# Helper: resolve and enforce safe path
def safe_path(rel_path: str) -> Path:
    # prevent absolute paths and path traversal
    p = (ROOT / rel_path).resolve()
    if not str(p).startswith(str(ROOT.resolve())):
        raise ValueError("Access denied: path outside allowed directory")
    return p

@mcp.tool
def read_file(path: str) -> dict:
    """
    Safe read file tool.
    - path: relative path inside the 'mcp_data' folder.
    Returns dict with { 'ok': True, 'text': '...' } or { 'ok': False, 'error': '...' }.
    """
    try:
        p = safe_path(path)
        if not p.exists():
            return {"ok": False, "error": f"File not found: {path}"}
        # Only read text files for now
        text = p.read_text(encoding="utf-8")
        return {"ok": True, "text": text}
    except Exception as e:
        return {"ok": False, "error": str(e)}

if __name__ == "__main__":
    print("Starting HTTP MCP file server at http://127.0.0.1:8000/mcp")
    mcp.run(transport="http", host="127.0.0.1", port=8000, path="/mcp")

'''What this does

ROOT = Path.cwd() / "mcp_data" creates a safe folder named mcp_data in the current working directory. All file access is restricted here.

safe_path() prevents absolute paths and directory traversal (no ../../etc/passwd).

@mcp.tool registers read_file as an MCP tool that returns a structured dict (easy to parse by the client or LLM).

mcp.run(...) exposes the server over HTTP at http://127.0.0.1:8000/mcp — networked and easy for separate client/agent processes.'''

