from fastmcp import FastMCP
from ollama import generate  # new import

mcp = FastMCP("ollama-mcp")

@mcp.tool
def generate_text(prompt: str, model: str = "mistral") -> dict:
    """
    Generate text using Ollama model.
    """
    try:
        result = generate(model=model, prompt=prompt)
        return {"ok": True, "text": result.text}
    except Exception as e:
        return {"ok": False, "error": str(e)}

if __name__ == "__main__":
    print("Starting Ollama MCP server at http://127.0.0.1:8000/mcp")
    mcp.run(transport="http", host="127.0.0.1", port=8000, path="/mcp")
