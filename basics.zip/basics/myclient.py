import asyncio
from fastmcp.client import Client

async def main():
    async with Client("http://127.0.0.1:8000/mcp") as client:
        result = await client.call_tool("add_numbers", {"a": 5, "b": 7})
        print("Result:", result)

if __name__ == "__main__":
    asyncio.run(main())
