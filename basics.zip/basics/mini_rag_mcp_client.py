import asyncio
from fastmcp.client import Client

async def main():
    url = "http://127.0.0.1:8000/mcp"
    async with Client(url) as client:
        tools = await client.list_tools()
        print("Tools available:", [t.name for t in tools])

        # Step 1: List files
        resp = await client.call_tool("list_dir", {})
        files = resp.structured_content.get("items", [])
        print("\nFiles in mcp_data:", files)

        if not files:
            # If no files, create one
            await client.call_tool("write_file", {
                "path": "example.txt",
                "content": "This is a sample document for mini-RAG demo.\nIt contains multiple lines of text."
            })
            files = ["example.txt"]
            print("Created example.txt for demo.")

        # Step 2: Read the first file
        file_name = files[0]
        resp = await client.call_tool("read_file", {"path": file_name})
        data = resp.structured_content
        if not data.get("ok"):
            print("Error reading file:", data.get("error"))
            return
        content = data["text"]
        print(f"\nContent of {file_name}:\n{content}")

        # Step 3: Generate a summary
        prompt = f"Summarize the following text concisely:\n\n{content}"
        resp = await client.call_tool("generate_text", {"prompt": prompt})
        summary_data = resp.structured_content
        if summary_data.get("ok"):
            summary = summary_data["text"]
            print("\nGenerated Summary:\n", summary)
        else:
            print("Error generating summary:", summary_data.get("error"))
            return

        # Step 4: Write summary to a new file
        summary_file = f"summary_of_{file_name}"
        resp = await client.call_tool("write_file", {
            "path": summary_file,
            "content": summary
        })
        if resp.structured_content.get("ok"):
            print(f"\nSummary saved to {summary_file}")
        else:
            print("Error writing summary:", resp.structured_content.get("error"))

if __name__ == "__main__":
    asyncio.run(main())
