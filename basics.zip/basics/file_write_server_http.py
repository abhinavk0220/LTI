import os
from pathlib import Path
from fastmcp import FastMCP

# Safe root folder for read/write
ROOT = Path.cwd() / "mcp_data"
ROOT.mkdir(exist_ok=True)

mcp = FastMCP("file-write-server")

# Helper: safe path resolver
def safe_path(rel_path: str) -> Path:
    p = (ROOT / rel_path).resolve()
    if not str(p).startswith(str(ROOT.resolve())):
        raise ValueError("Access denied: path outside allowed directory")
    return p

@mcp.tool
def write_file(path: str, content: str) -> dict:
    """
    Safe write file tool.
    - path: relative path inside 'mcp_data'
    - content: text to write
    Returns dict with {'ok': True} or {'ok': False, 'error': '...'}
    """
    try:
        p = safe_path(path)
        p.write_text(content, encoding="utf-8")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

if __name__ == "__main__":
    print("Starting HTTP MCP file write server at http://127.0.0.1:8000/mcp")
    mcp.run(transport="http", host="127.0.0.1", port=8000, path="/mcp")

    '''Same safe folder pattern as read_file

write_file tool takes a relative path + content

Returns structured content for easy LLM/agent parsing

Demonstrates input validation (safe_path) → teach students security first'''