import os
from pathlib import Path
from fastmcp import FastMCP

# Safe root folder for all file operations
ROOT = Path.cwd() / "mcp_data"
ROOT.mkdir(exist_ok=True)

mcp = FastMCP("mini-toolkit-server")

def safe_path(rel_path: str) -> Path:
    p = (ROOT / rel_path).resolve()
    if not str(p).startswith(str(ROOT.resolve())):
        raise ValueError("Access denied: path outside allowed directory")
    return p

@mcp.tool
def read_file(path: str) -> dict:
    """Read a text file inside mcp_data safely."""
    try:
        p = safe_path(path)
        if not p.exists():
            return {"ok": False, "error": f"File not found: {path}"}
        return {"ok": True, "text": p.read_text(encoding="utf-8")}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@mcp.tool
def write_file(path: str, content: str) -> dict:
    """Write a text file inside mcp_data safely."""
    try:
        p = safe_path(path)
        p.write_text(content, encoding="utf-8")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@mcp.tool
def list_dir(path: str = "") -> dict:
    """List files/folders inside mcp_data or subfolders."""
    try:
        p = safe_path(path)
        if not p.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        items = [f.name for f in p.iterdir()]
        return {"ok": True, "items": items}
    except Exception as e:
        return {"ok": False, "error": str(e)}

if __name__ == "__main__":
    print("Starting mini-toolkit MCP server at http://127.0.0.1:8000/mcp")
    mcp.run(transport="http", host="127.0.0.1", port=8000, path="/mcp")

'''Safe operations in one folder — avoids security risks.

Each tool returns structured output (ok + text or items) — easy for agents to parse.

list_dir introduces the idea of tool chaining: agents can read a directory, then read files inside.

This is exactly how RAG workflows start: discover documents → read content → write results.'''