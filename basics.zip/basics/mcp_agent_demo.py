import asyncio
from fastmcp.client import Client
from langchain.agents import ZeroShotAgent, AgentExecutor
from langchain.agents.tools import Tool
from langchain.prompts import StringPromptTemplate
from langchain.llms.base import LLM



# ----------------------------
# Custom LLM that calls MCP
# ----------------------------
class MCP_LLM(LLM):
    def __init__(self, client: Client, model="mistral"):
        self.client = client
        self.model = model

    @property
    def _llm_type(self):
        return "mcp"

    def _call(self, prompt, stop=None):
        """Sync call wrapper for LangChain v1.1.0"""
        resp = asyncio.run(self.client.call_tool(
            "generate_text", {"prompt": prompt, "model": self.model}
        ))
        return resp.structured_content.get("text", "")

# ----------------------------
# MCP Tool Wrappers
# ----------------------------
async def create_mcp_tools():
    client = Client("http://127.0.0.1:8000/mcp")
    await client.__aenter__()

    tools = []

    def read_file(path: str):
        resp = asyncio.run(client.call_tool("read_file", {"path": path}))
        return resp.structured_content.get("text", "")

    tools.append(Tool(
        name="read_file",
        func=read_file,
        description="Read text from a file in mcp_data"
    ))

    def write_file(args: dict):
        resp = asyncio.run(client.call_tool("write_file", args))
        return resp.structured_content.get("ok", False)

    tools.append(Tool(
        name="write_file",
        func=write_file,
        description="Write text to a file in mcp_data"
    ))

    return client, tools

# ----------------------------
# Prompt template for ZeroShotAgent
# ----------------------------
class MCPPromptTemplate(StringPromptTemplate):
    input_variables = ["input"]

    def format(self, **kwargs) -> str:
        return kwargs["input"]

# ----------------------------
# Run Agent
# ----------------------------
async def main():
    client, tools = await create_mcp_tools()
    llm = MCP_LLM(client)

    prompt = MCPPromptTemplate()

    agent = ZeroShotAgent(
        tools=tools,
        llm=llm,
        prompt=prompt,
        verbose=True
    )

    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)

    # Task: read → summarize → write
    task = (
        "Read the file 'example.txt', summarize it concisely, "
        "and write the summary to 'summary_example.txt'."
    )

    print("\n=== Running MCP Agent ===")
    result = agent_executor.run(task)
    print("\n=== Agent Finished ===")
    print("Result:", result)

    await client.__aexit__(None, None, None)

if __name__ == "__main__":
    asyncio.run(main())
