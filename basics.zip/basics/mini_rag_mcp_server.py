import os
from pathlib import Path
from fastmcp import FastMCP
from ollama import generate

# Root folder for safe file operations
ROOT = Path.cwd() / "mcp_data"
ROOT.mkdir(exist_ok=True)

mcp = FastMCP("mini-rag-server")

def safe_path(rel_path: str) -> Path:
    p = (ROOT / rel_path).resolve()
    if not str(p).startswith(str(ROOT.resolve())):
        raise ValueError("Access denied: path outside allowed directory")
    return p

@mcp.tool
def read_file(path: str) -> dict:
    """Read a text file safely."""
    try:
        p = safe_path(path)
        if not p.exists():
            return {"ok": False, "error": f"File not found: {path}"}
        return {"ok": True, "text": p.read_text(encoding="utf-8")}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@mcp.tool
def write_file(path: str, content: str) -> dict:
    """Write a text file safely."""
    try:
        p = safe_path(path)
        p.write_text(content, encoding="utf-8")
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@mcp.tool
def list_dir(path: str = "") -> dict:
    """List files/folders inside mcp_data."""
    try:
        p = safe_path(path)
        if not p.exists():
            return {"ok": False, "error": f"Path not found: {path}"}
        items = [f.name for f in p.iterdir()]
        return {"ok": True, "items": items}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@mcp.tool
def generate_text(prompt: str, model: str = "mistral") -> dict:
    """Generate text using Ollama Mistral."""
    try:
        resp = generate(model=model, prompt=prompt)
        # Get the generated text
        text = "\n".join(resp.output) if hasattr(resp, "output") else str(resp)
        return {"ok": True, "text": text}
    except Exception as e:
        return {"ok": False, "error": str(e)}


if __name__ == "__main__":
    print("Starting mini-RAG MCP server at http://127.0.0.1:8000/mcp")
    mcp.run(transport="http", host="127.0.0.1", port=8000, path="/mcp")
