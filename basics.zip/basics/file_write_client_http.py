import asyncio
from fastmcp.client import Client

async def main():
    url = "http://127.0.0.1:8000/mcp"
    async with Client(url) as client:
        # list tools (optional)
        tools = await client.list_tools()
        print("Tools available on server:", [t.name for t in tools])

        # write to file
        resp = await client.call_tool("write_file", {
            "path": "student_notes.txt",
            "content": "Hello students!\nThis file was created by MCP write_file tool."
        })
        data = resp.structured_content
        if data and data.get("ok"):
            print("File written successfully!")
        else:
            print("Error writing file:", data.get("error") if data else "Unknown error")

if __name__ == "__main__":
    asyncio.run(main())
