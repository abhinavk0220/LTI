import asyncio
from fastmcp.client import Client

async def main():
    url = "http://127.0.0.1:8000/mcp"
    async with Client(url) as client:
        tools = await client.list_tools()
        print("Tools available:", [t.name for t in tools])

        # 1. Write a file
        resp = await client.call_tool("write_file", {
            "path": "notes1.txt",
            "content": "This is a test file for MCP mini-toolkit."
        })
        print("Write file response:", resp.structured_content)

        # 2. List directory
        resp = await client.call_tool("list_dir", {})
        print("List directory response:", resp.structured_content)

        # 3. Read the file
        resp = await client.call_tool("read_file", {"path": "notes1.txt"})
        data = resp.structured_content
        if data.get("ok"):
            print("\n--- File content ---\n", data["text"])
        else:
            print("Error reading file:", data.get("error"))

if __name__ == "__main__":
    asyncio.run(main())
