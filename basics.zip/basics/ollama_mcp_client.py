import asyncio
from fastmcp.client import Client

async def main():
    url = "http://127.0.0.1:8000/mcp"
    async with Client(url) as client:
        tools = await client.list_tools()
        print("Tools available:", [t.name for t in tools])

        # Call generate_text
        prompt = "Write a short motivational quote for students learning AI:"
        resp = await client.call_tool("generate_text", {"prompt": prompt})
        data = resp.structured_content

        if data.get("ok"):
            print("\nGenerated Text:\n", data["text"])
        else:
            print("Error:", data.get("error"))

if __name__ == "__main__":
    asyncio.run(main())
